<link rel="stylesheet" href="estilo/estilo_index.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Advent+Pro:wght@100;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./css/estilo_index.css">
<header>
<div style="position: fixed;
        top: 0px;
        left: 0px; width: 100%; ">

    <div class="topnav">
        <div class="logo">
            <a href="index.php">
                <img src="imagenes/soyneat_logo.png" alt="logotipo" width="150" height="90">
            </a>
        </div>
        <div class="menu">
            <ul>

                <li><a href="impacto.php">Nuestro Impacto</a></li>

                <li><a href="conocenos.php">Conócenos</a></li>


                <li><a href="carta.php">Carta</a></li>


                <li><a href="login.php">Únete</a></li>


                <li><a href="pedido.php">Hacer Pedido</a></li>

            </ul>
        </div>
    </div>
    </div>
</header>