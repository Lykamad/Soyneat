<div class="footer">
	&copy; <?php print date("Y");?>
</div>
<link rel="stylesheet" href="../estilo/estilo_index.css>
