<title><?php print $PAGE_TITLE;?></title>

<?php if ($CURRENT_PAGE == "index") { ?>
	<meta name="description" content="" />
	<meta name="keywords" content="" /> 
<?php } ?>

<link rel="stylesheet" href="../estilo/estilo_index.css>